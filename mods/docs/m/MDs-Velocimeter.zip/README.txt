# MD's Velocimeter

Author: MatiDragon

> update, create or move the 'cleo_settings.ini' at
> folder of CLEO with the following lines:




[MDsVelocimeter];      --> https://matidragon-yt.github.io/page/mods/m
; Km/h - 4.0
; M/h  - 1.0
; M/s  - 0.25
TextAtDisplay=Km/h
MultipliedNumber=4.0
samp=1