MD's Velocimeter 2.5D _By MatiDragon_
=======================

El primer velocimetro digital en *2.5D* que veras en GTA SA y personalizable para el tipo de medicion que desees

A diferencia de muchos otros medidores, este se mantienen a un lado adaptandose constantemente a los movimientos de la posicion del jugador. Dandonos uno angulos de vision exquisitas para el multi-jugador y otros mods complementarios, como:

* [Jump In Motobike](https://matidragon-yt.github.io/page/mods/i.md)\
  (para saltar en motos)

* [Turn In Air](https://matidragon-yt.github.io/page/mods/j.md)\
  (para girar con las motos en el aire)

* [Stay On The Bike](https://matidragon-yt.github.io/page/mods/k.md)\
  (para no caerse de las bicis y motos)

* [Aquatic Motobike](https://matidragon-yt.github.io/page/mods/l.md)\
  (para que las motos floten en el agua)

* [Put On Helmets](https://matidragon-yt.github.io/page/mods/9.md)\
  (para ponerse cascos al estilo de GTA V)

Y todo configurable desde un archivo **.INI** en la carpeta de **CLEO_SETTINGS**.
Con las siguientes lineas:

```
[MDsVelocimeter]; By MatiDragon
Text=Km/h
Multipliquer=4.0
Font=3
Samp=1
```

* `Text` - Para cambiar el texto que se mostrara junto al número del medidor.
* `Multipliquer` - Para hacer mas grande número que se muestra y viceversa.
* `Font` - Para cambiar el estilo de fuente, entre tres variantes.
* `Samp` - Para activarlo y desactivarlo para SAMP.

Ejemplos:
| formato de medida          |    texto   | multiplicador |
| -------------------------- | ---------- | ------------- |
| Kilometros por hora        |            |               |
|    (por defecto)           |    Km/h    |      4.0      |
| Metros por minuto          |    M/m     |      1.0      |
| Metros por segundo         |    M/s     |      0.25     |