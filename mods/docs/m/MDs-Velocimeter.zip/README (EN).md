MD's Velocimeter 2.5D _By MatiDragon_ v. 1.2
=======================

The first digital speedometer in *2.5D* that you will see in GTA SA and customizable for the type of measurement you want.

Unlike many other gauges, this one stands to the side and constantly adapts to the movements of the player's position. Giving us an exquisite viewing angles for multiplayer and other complementary mods, such as:

* [Jump In Motobike](https://matidragon-yt.github.io/page/mods/i.md)\
  (for jump on motorcycles)

* [Turn In Air](https://matidragon-yt.github.io/page/mods/j.md)\
  (for turn with the motorcycles in the air)

* [Stay On The Bike](https://matidragon-yt.github.io/page/mods/k.md)\
  (for not to fall off bicycles and motorcycles)

* [Aquatic Sanchez](https://matidragon-yt.github.io/page/mods/l.md)\
  (for the Sanchez to float on the water)

* [Put On Helmets](https://matidragon-yt.github.io/page/mods/9.md)\
  (for to put on helmets in the style of GTA V)

And all configurable from a **.INI** file in the **CLEO_SETTINGS** folder.
With the following lines:

```
[MDsVelocimeter]; By MatiDragon
Text=Km/h~n~
Multipliquer=4.0
Font=3
Samp=1
```

* `Text` - To change the text to be displayed next to the meter number.
* `Multipliquer` - To make the displayed number larger and vice versa.
* `Font` - To change the font style, between three variants.
* `Samp` - To enable and disable it for SAMP.

Examples:
| measurement format          |    text    |  multipliquer  |
| --------------------------- | ---------- | -------------- |
| Kilometers per hour         |            |                |
|    (by default)             |   Km/h~n~  |       4.0      |
| Meters per minute           |   M/m~n~   |       1.0      |
| Meters per second           |   M/s~n~   |       0.25     |